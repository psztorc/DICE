This directory contains:

1] The DICE 2013R model in a gms file "DICE2013R_100413_rockyroad.gms"
2] A REQUIRED directory labeled "Include" which contains other *.gms files. These files:
	a] describe various policy scenarios for the DICE model to use,
	b] contain input data for scenarios requiring additional information (a Copenhagen participation fraction vector, for example),
	c] contain code to produce a consistent output of nearly all parameters/variables handled by DICE,
	d] are structured to allow users to easily create and edit new modules without breaking the core DICE model.*

Be sure that the gms file and associated Include folder are BOTH in your GAMS working directory ('project directory'), ie in the same folder that your
Project file .gpr is located in (assuming you use the standard gamside).

*Those wishing to substantially create and edit scenarios may find it useful to use the Gtree software, available for free at http://www3.lei.wur.nl/gamstools/.